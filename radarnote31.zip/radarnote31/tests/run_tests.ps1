# Runner de validación para SCEL_ATC_Radar.html
# Regenera el harness en %TEMP%\opencode, inyecta captura de errores + hold_test.js
# y ejecuta Chrome headless (parser JS real). Imprime el resultado (RES::...) y ERR:n.
# Uso:  powershell -ExecutionPolicy Bypass -File run_tests.ps1
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot          # radarnote31/
$src=Join-Path $root 'SCEL_ATC_Radar.html'
if(!(Test-Path -LiteralPath $src)){ Write-Error "No existe $src" }
$tmp=Join-Path $env:TEMP 'opencode'
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$dst=Join-Path $tmp 'SCEL_TEST.html'

$c=Get-Content -LiteralPath $src -Raw -Encoding UTF8
$injHead='<script>window.__errs=[];window.onerror=function(m,s,l){window.__errs.push(String(m).slice(0,120)+" @line "+l);};</script>'
$injEnd='<script src="hold_test.js"></script><script>document.title=document.title+" || ERR:"+window.__errs.length;</script>'
if($c -match '(?i)<head>'){ $c=$c -replace '(?i)<head>',("<head>"+$injHead) } else { $c=$injHead+$c }
if($c -match '(?i)</body>'){ $c=$c -replace '(?i)</body>',($injEnd+"</body>") } else { $c=$c+$injEnd }
[System.IO.File]::WriteAllText($dst,$c,(New-Object System.Text.UTF8Encoding($false)))

# JS externos que el HTML carga por <script src> (resolución relativa en temp)
foreach($f in @('coast_xy_smooth.js','border_xy.js')){
  $p=Join-Path $root $f
  if(Test-Path -LiteralPath $p){ Copy-Item -LiteralPath $p -Destination $tmp -Force }
}
# fraseología editable (carga síncrona por XHR en el HTML) — el suite valida el JSON real
$jsonP=Join-Path $root 'fraseologia_editada.json'
if(Test-Path -LiteralPath $jsonP){ Copy-Item -LiteralPath $jsonP -Destination $tmp -Force }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'hold_test.js') -Destination $tmp -Force

$chrome='C:\Program Files\Google\Chrome\Application\chrome.exe'
if(!(Test-Path -LiteralPath $chrome)){ $chrome=(Get-Command chrome -ErrorAction SilentlyContinue).Source }
if(!$chrome){ Write-Error 'Chrome no encontrado' }

# Start-Process con redirección a archivo: el patrón `& chrome ... |` se cuelga en este entorno
$so=Join-Path $tmp 'chrome_out.txt'
$se=Join-Path $tmp 'chrome_err.txt'
Remove-Item $so,$se -ErrorAction SilentlyContinue
$p=Start-Process -FilePath $chrome -ArgumentList '--headless=new','--disable-gpu','--no-first-run','--disable-extensions','--allow-file-access-from-files','--virtual-time-budget=8000','--dump-dom',("file:///"+($dst -replace '\\','/')) -RedirectStandardOutput $so -RedirectStandardError $se -Wait -PassThru -NoNewWindow
$line=Select-String -Path $so -Pattern '<title>RES::' -ErrorAction SilentlyContinue | ForEach-Object { $_.Line }
if($line){ $line } else {
  # Diagnostico: Chrome headless sin salida (instalacion corrupta / sesion existente)
  $diag='NO RESULT - revisa chrome_err.txt'
  $verDir=Join-Path (Split-Path -Parent $chrome) ((Get-ChildItem (Split-Path -Parent $chrome) -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^\d+\.' } | Sort-Object Name -Descending | Select-Object -First 1).Name)
  if($verDir -and !(Test-Path -LiteralPath (Join-Path $verDir 'chrome.exe'))){
    $diag="NO RESULT - Chrome corrupto: falta chrome.exe en $verDir (actualizacion interrumpida). Repara Chrome o valida con el navegador integrado de OpenWork (servidor HTTP local + SCEL_TEST.html)."
  } elseif(Test-Path -LiteralPath $se){
    $e=(Get-Content -LiteralPath $se -Raw -ErrorAction SilentlyContinue)
    if($e -match 'sesi[oó]n de navegador existente'){ $diag='NO RESULT - Chrome esta abierto en una sesion normal; cierralo o usa --user-data-dir unico.' }
  }
  $diag
}