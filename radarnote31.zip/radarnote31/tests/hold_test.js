// Test funcional de SCEL_ATC_Radar.html — reconocimiento de esperas (hold) y voz robusta.
// Se inyecta antes de </body> por run_tests.ps1; escribe el resultado en document.title.
(function(){
  window.__res=[];
  try{
    // ── Test 1: nlpHoldFix (función pura) ──
    var cases=[
      ['LAN101 autorizado hasta UGOLA, mantenga patron de espera publicado, prevea autorizacion de aproximacion a las 15:30','UGOLA'],
      ['SKY220 hold UGOLA','UGOLA'],
      ['LAN101 hold at UGOLA','UGOLA'],
      ['LAN101 espere en UGOLA','UGOLA'],
      ['LAN101 espera sobre UGOLA','UGOLA'],
      ['LAN101 espera a UGOLA','UGOLA'],
      ['LAN101 espera al UGOLA','UGOLA'],
      ['LAN101 ingrese a patron de espera UGOLA','UGOLA'],
      ['LAN101 cleared to UGOLA, hold as published','UGOLA'],
      ['LAN101 direct UGOLA',null],
      ['LAN101 espera sobre MORPA nivel de vuelo 140','MORPA'],
      ['LAN101 autorizado hasta DABIT, mantenga patron de espera publicado','DABIT'],
      ['LAN101 hold heading',null]
    ];
    for(var i=0;i<cases.length;i++){
      var ph=cases[i][0],exp=cases[i][1];
      var got=nlpHoldFix(ph.toLowerCase());
      window.__res.push('HF:'+(got===exp?'OK':'FAIL')+' ['+ph.slice(0,40)+'] -> '+got+(exp?' (exp '+exp+')':' (exp null)'));
    }
    // ── Test 1b: _normSpoken (números hablados dígito a dígito) ──
    var ns=[
      ['rumbo uno ocho cero','rumbo 180'],
      ['nivel de vuelo uno cuatro cero','nivel de vuelo 140'],
      ['velocidad dos cinco cero','velocidad 250'],
      ['one eight zero','180'],
      ['a las uno cinco','a las uno cinco'],          // contexto de hora: sin colapsar
      ['a las quince treinta','a las quince treinta'], // compuesto: sin colapsar
      ['nivel de vuelo ciento cuarenta','nivel de vuelo ciento cuarenta'], // compuesto
      ['LAN uno cero uno hold UGOLA','LAN 101 hold UGOLA'],
      ['directo ugola','directo ugola'],
      ['uno dos tres','123'],
      ['hold UGOLA por favor','hold UGOLA'],
      ['ascienda por favor a nivel uno cuatro cero','ascienda a nivel 140'],
      ['please hold at UGOLA','hold at UGOLA']
    ];
    for(var j=0;j<ns.length;j++){
      var nph=ns[j][0],nexp=ns[j][1];
      var ngot=_normSpoken(nph);
      window.__res.push('NS:'+(ngot===nexp?'OK':'FAIL')+' ['+nph+'] -> "'+ngot+'"');
    }
    // ── Test 2: nlpParse canonical ──
    var ac={id:'LAN101',x:0,y:0,hdg:180,tHdg:180,alt:14000,tAlt:14000,cfl:140,assignedFL:140,selAlt:14000,route:null,routeIdx:-1,hold:null,holdPhase:null,holdDist:0,dctWpt:null,vectored:false,locMode:false,gsMode:false,atcAlt:false,expectAppr:null,lastCmd:'',turnDir:null,spd:250,tSpd:250,ias:250,gspd:250};
    aircraft.push(ac);
    var r1=nlpParse('LAN101 autorizado hasta UGOLA, mantenga patron de espera publicado, prevea autorizacion de aproximacion a las 15:30');
    window.__res.push('NLP1:'+(r1&&r1.canonical));
    var r2=nlpParse('LAN101 espera sobre UGOLA nivel de vuelo 140');
    window.__res.push('NLP2:'+(r2&&r2.canonical));
    var r3=nlpParse('LAN101 espera sobre UGOLA nivel de vuelo ciento cuarenta');
    window.__res.push('NLP3:'+(r3&&r3.canonical));
    var r4=nlpParse('LAN101 espera sobre UGOLA a las quince treinta');
    window.__res.push('NLP4:'+(r4&&r4.canonical));
    var r5=nlpParse('LAN101 hold UGOLA');
    window.__res.push('NLP5:'+(r5&&r5.canonical));
    var r7=nlpParse('LAN101 esperando en UGOLA');
    window.__res.push('NLP7:'+(r7&&r7.canonical));
    var r6=nlpParse('LAN101 espera sobre UGOLA a las 15:30');
    window.__res.push('NLP6:'+(r6&&r6.canonical));
    // ── Test 2b: nlpParse con números hablados dígito a dígito ──
    var r8=nlpParse('LAN101 rumbo uno ocho cero');
    window.__res.push('NLP8:'+(r8&&r8.canonical)+' (exp LAN101 turn heading 180)');
    var r9=nlpParse('LAN101 ascienda a nivel de vuelo uno cuatro cero');
    window.__res.push('NLP9:'+(r9&&r9.canonical)+' (exp LAN101 climb 140)');
    // ── Test 2c: adaptación a desviaciones de fraseología (intención clara) ──
    var r10=nlpParse('LAN101 240 a la izquierda');
    window.__res.push('NLP10:'+(r10&&r10.canonical)+' (exp LAN101 turn left heading 240)');
    var r11=nlpParse('LAN101 a UGOLA directo');
    window.__res.push('NLP11:'+(r11&&r11.canonical)+' (exp LAN101 direct UGOLA)');
    ac.alt=12000;
    var r12=nlpParse('LAN101 nivel 140');
    window.__res.push('NLP12:'+(r12&&r12.canonical)+' (exp LAN101 climb 140)');
    ac.alt=14000;
    var r13=nlpParse('LAN101 proa 240');
    window.__res.push('NLP13:'+(r13&&r13.canonical)+' (exp LAN101 turn heading 240)');
    var r14=nlpParse('LAN101 vaya directo UGOLA');
    window.__res.push('NLP14:'+(r14&&r14.canonical)+' (exp LAN101 direct UGOLA)');
    var r15=nlpParse('LAN101 suba a nivel 140');
    window.__res.push('NLP15:'+(r15&&r15.canonical)+' (exp LAN101 climb 140)');
    // ── Test 3: processVoice ejecución ──
    processVoice('LAN101 autorizado hasta UGOLA, mantenga patron de espera publicado, prevea autorizacion de aproximacion a las 15:30');
    window.__res.push('PV1:hold='+ac.hold+' expect='+ac.expectAppr+' tAlt='+ac.tAlt+' lastCmd='+ac.lastCmd);
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera sobre MORPA nivel de vuelo 140');
    window.__res.push('PV2:hold='+ac.hold+' tAlt='+ac.tAlt);
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera sobre UGOLA nivel de vuelo 80');
    window.__res.push('PV3:hold='+ac.hold+' (debe ser null: FL80 < FL090 publicado)');
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera a UGOLA');
    window.__res.push('PV4:hold='+ac.hold+' (espera a UGOLA)');
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 hold UGOLA');
    window.__res.push('PV5:hold='+ac.hold+' (hold UGOLA)');
    // ── Test 3b: processVoice con nivel hablado dígito a dígito ──
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera sobre UGOLA nivel de vuelo uno cuatro cero');
    window.__res.push('PV7:hold='+ac.hold+' tAlt='+ac.tAlt+' (nivel hablado)');
    // ── Test 3c: instrucción incompleta → piloto pide confirmación en el readback ──
    var rb=document.getElementById('readbackBanner');
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 hold UGOLA');
    window.__res.push('PV8:hold='+ac.hold+' rb="'+(rb?rb.textContent:'')+'"');
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera sobre UGOLA nivel de vuelo 140');
    window.__res.push('PV9:hold='+ac.hold+' rb="'+(rb?rb.textContent:'')+'"');
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera sobre UGOLA expect 1530');
    window.__res.push('PV10:hold='+ac.hold+' expect='+ac.expectAppr+' rb="'+(rb?rb.textContent:'')+'"');
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    processVoice('LAN101 espera sobre UGOLA nivel de vuelo 140 expect 1530');
    window.__res.push('PV11:hold='+ac.hold+' expect='+ac.expectAppr+' rb="'+(rb?rb.textContent:'')+'"');
    // ── Test 4: canonical re-ejecutado por processVoice (round-trip) ──
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    if(r1&&r1.canonical){processVoice(r1.canonical);}
    window.__res.push('PV6(roundtrip):hold='+ac.hold+' expect='+ac.expectAppr+' tAlt='+ac.tAlt);
    // ── Test 5: matchCS difuso (callsign mal escuchado) ──
    var mi=matchCS('lam 101 hold ugola');
    window.__res.push('CS1:'+(mi===0?'OK':'FAIL')+' (lam101 -> LAN101 idx '+mi+')');
    var mi2=matchCS('sky 220 hold ugola');
    window.__res.push('CS2:'+(mi2===-1?'OK':'FAIL')+' (sky220 -> -1 idx '+mi2+')');
    // ── Test 6: processTextCmd detección de éxito (usada por el bucle de voz) ──
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    var ok1=processTextCmd('LAN101 hold UGOLA');
    window.__res.push('PT1:'+(ok1===true?'OK':'FAIL')+' (hold -> '+ok1+') hold='+ac.hold);
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    var ok3=processTextCmd('LAN101 espera sobre UGOLA nivel de vuelo uno cuatro cero');
    window.__res.push('PT3:'+(ok3===true?'OK':'FAIL')+' (voz completa -> '+ok3+') hold='+ac.hold+' tAlt='+ac.tAlt);
    var ok2=processTextCmd('xyzzy plugh');
    window.__res.push('PT2:'+(ok2===true?'OK':'FAIL')+' (basura con seleccion -> '+ok2+', fallback "adelante" esperado)');
    // PT2b: sin aeronave seleccionada, la basura debe fallar (no hay "adelante" por fallback)
    selected=-1;
    var ok2b=processTextCmd('xyzzy plugh');
    window.__res.push('PT2b:'+(ok2b===false?'OK':'FAIL')+' (basura sin seleccion -> '+ok2b+')');
    // PT4/PT5: intención NO clara → el piloto solicita confirmación de instrucciones.
    // silent=true (alternativas intermedias de voz) NO responde; la última/texto directo SÍ.
    selected=0;
    var rb2=document.getElementById('readbackBanner');
    if(rb2)rb2.textContent='';
    var ok4=processTextCmd('LAN101 zumba 350',true);
    window.__res.push('PT4:'+(ok4===false?'OK':'FAIL')+' (silent -> '+ok4+') rb="'+(rb2?rb2.textContent:'')+'"');
    var ok5=processTextCmd('LAN101 zumba 350');
    window.__res.push('PT5:'+(ok5===false?'OK':'FAIL')+' (-> '+ok5+') rb="'+(rb2?rb2.textContent:'')+'"');
    // PT6: desviación con relleno de cortesía → se entiende y se ejecuta
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.atcAlt=false;
    var ok6=processTextCmd('LAN101 hold UGOLA por favor');
    window.__res.push('PT6:'+(ok6===true?'OK':'FAIL')+' (filler -> '+ok6+') hold='+ac.hold);
    // PT7: instrucciones MÚLTIPLES en una frase → ambas se ejecutan
    ac.hold=null;ac.expectAppr=null;ac.tAlt=14000;ac.tHdg=180;ac.atcAlt=false;
    var ok7=processTextCmd('LAN101 vire a la izquierda rumbo 240, ascienda a nivel 140');
    window.__res.push('PT7:'+(ok7===true?'OK':'FAIL')+' (multi -> '+ok7+') tHdg='+ac.tHdg+' tAlt='+ac.tAlt);
    // PT8: espera + ascenso en una frase (conector "y") — instrucciones compatibles
    ac.hold=null;ac.expectAppr=null;ac.tAlt=12000;ac.atcAlt=false;
    var ok8=processTextCmd('LAN101 espera sobre UGOLA y ascienda a nivel 140');
    window.__res.push('PT8:'+(ok8===true?'OK':'FAIL')+' (multi2 -> '+ok8+') hold='+ac.hold+' tAlt='+ac.tAlt);
    // ── Test 7: LENGUAJE IMPLÍCITO editable (FRASES → LENGUAJE, sección "lenguaje" del JSON) ──
    // LG1: regex construidos desde LANG_IMPLICITO (defaults) — prefijos y palabras completas
    window.__res.push('LG1a:'+(_RE_HDG&&_RE_HDG.test('gire a la izquierda')?'OK':'FAIL')+' (hdg prefijo "gir")');
    window.__res.push('LG1b:'+(_RE_HDG&&_RE_HDG.test('proa 240')?'OK':'FAIL')+' (hdg "proa")');
    window.__res.push('LG1c:'+(_RE_HDG&&_RE_HDG.test('rumbo 240')?'OK':'FAIL')+' (hdg "rumbo")');
    // LG2: acentos opcionales — "patrón" ≡ "patron" (clases [oó] generadas por _buildLangRegexes)
    window.__res.push('LG2a:'+(_RE_HOLD&&_RE_HOLD.test('patrón de espera')?'OK':'FAIL')+' (hold acentuado)');
    window.__res.push('LG2b:'+(_RE_HOLD&&_RE_HOLD.test('patron de espera')?'OK':'FAIL')+' (hold sin acento)');
    // LG3: "diríjase" ≡ "dirijase"
    window.__res.push('LG3a:'+(_RE_DIRECT&&_RE_DIRECT.test('diríjase a UGOLA')?'OK':'FAIL')+' (direct acentuado)');
    window.__res.push('LG3b:'+(_RE_DIRECT&&_RE_DIRECT.test('dirijase a UGOLA')?'OK':'FAIL')+' (direct sin acento)');
    // LG4: editar LANG_IMPLICITO + reconstruir → el nuevo sinónimo aplica y el viejo deja de matchear
    LANG_IMPLICITO.hdg=['proa'];
    _buildLangRegexes();
    window.__res.push('LG4a:'+(_RE_HDG.test('proa 240')?'OK':'FAIL')+' (nuevo sinonimo "proa")');
    window.__res.push('LG4b:'+(!_RE_HDG.test('rumbo 240')?'OK':'FAIL')+' (viejo "rumbo" ya no matchea)');
    // LG5: _populateFromJson carga la sección "lenguaje" del JSON → sobreescribe LANG_IMPLICITO
    _populateFromJson({readbacks:[],lenguaje:{acciones:{hdg:['rumbo']}}},'test');
    _buildLangRegexes();
    window.__res.push('LG5a:'+(_RE_HDG.test('rumbo 240')?'OK':'FAIL')+' (JSON carga "rumbo")');
    window.__res.push('LG5b:'+(!_RE_HDG.test('proa 240')?'OK':'FAIL')+' (JSON quita "proa")');
    // LG6: frasesLang (editor FRASES → LENGUAJE) escribe en _frasesData.lenguaje.acciones
    _frasesData={readbacks:[],lenguaje:{acciones:{}}};
    frasesLang({dataset:{lang:'hdg'},value:'proa, rumbo'});
    var lg6=_frasesData.lenguaje.acciones.hdg;
    window.__res.push('LG6:'+(lg6&&lg6.length===2&&lg6[0]==='proa'&&lg6[1]==='rumbo'?'OK':'FAIL')+' (frasesLang -> '+JSON.stringify(lg6)+')');
    // ── Test 8: botón de voz — regresión strict-mode (variables implícitas) ──
    // El script corre con "use strict"; _recogLangTry/_noSpeechTries deben estar
    // DECLARADAS (let) o startVoice() lanza ReferenceError y el botón no hace nada.
    window.__res.push('VB1:'+(typeof _recogLangTry==='number'&&typeof _noSpeechTries==='number'?'OK':'FAIL')+' (contadores declarados)');
    var vbThrew=false;
    try{ toggleVoice(); }catch(e){ vbThrew=true; window.__res.push('VB2:EXC '+e.message); }
    window.__res.push('VB2:'+(vbThrew?'FAIL':'OK')+' (toggleVoice sin excepción)');
    if(voiceActive){ try{ toggleVoice(); }catch(e){} } // detener si quedó activo
    // ── Test 9: readback de espera/abandono — nueva fraseología ──
    // hold:  "sobre {fix} ingreso a patrón de espera publicado"
    // leave: "abandonando patrón de espera sobre {fix}, reanudo {star} o volando directo a {fix}"
    var rb9=document.getElementById('readbackBanner');
    ac.starName='SIMOK7B';
    readback(ac,'hold','UGOLA');
    var rbHold=rb9?rb9.textContent:'';
    window.__res.push('RB1:'+(rbHold.indexOf('sobre ugola ingreso a patrón de espera publicado')>=0?'OK':'FAIL')+' (hold rb="'+rbHold+'")');
    readback(ac,'leave','UGOLA');
    var rbLeave=rb9?rb9.textContent:'';
    window.__res.push('RB2:'+(rbLeave.indexOf('abandonando patrón de espera sobre ugola')>=0&&rbLeave.indexOf('reanudo')>=0&&rbLeave.indexOf('volando directo a ugola')>=0?'OK':'FAIL')+' (leave rb="'+rbLeave+'")');
    // ── Test 10: sección HELP — comandos permitidos (voz y texto) ──
    window.__res.push('HP1:'+(typeof HELP_CMDS!=='undefined'&&HELP_CMDS.length>=10?'OK':'FAIL')+' (categorías='+HELP_CMDS.length+')');
    var hpThrew=false;
    try{ openHelpModal(); _helpRender(); }catch(e){ hpThrew=true; window.__res.push('HP2:EXC '+e.message); }
    var hpTabs=document.getElementById('hpTabs');
    var hpList=document.getElementById('hpList');
    window.__res.push('HP2:'+(hpThrew?'FAIL':'OK')+' (openHelpModal sin excepción)');
    window.__res.push('HP3:'+(hpTabs&&hpTabs.children.length===HELP_CMDS.length?'OK':'FAIL')+' (tabs='+(hpTabs?hpTabs.children.length:'0')+')');
    window.__res.push('HP4:'+(hpList&&hpList.children.length>0?'OK':'FAIL')+' (cards='+(hpList?hpList.children.length:'0')+')');
    closeHelpModal();
    // ── Test 11: OFFLINE — sección SECTORES (sectores de control) ──
    window.__res.push('SC1:'+(OFF_SCHEMAS.sectores&&OFF_SCHEMAS.sectores.title==='SECTORES DE CONTROL'?'OK':'FAIL')+' (schema sectores)');
    window.__res.push('SC2:'+(typeof SECTORES==='object'&&SECTORES!==null?'OK':'FAIL')+' (SECTORES definido)');
    var scBuilt=_offFromBuiltins('sectores');
    window.__res.push('SC3:'+(Array.isArray(scBuilt)?'OK':'FAIL')+' (_offFromBuiltins sectores -> array)');
    var scBtn=Array.prototype.slice.call(document.querySelectorAll('.off-btn')).filter(function(b){return b.textContent.indexOf('SECTORES')>=0;});
    window.__res.push('SC4:'+(scBtn.length>0?'OK':'FAIL')+' (botón SECTORES en OFFLINE)');
    var scDraw=false;
    try{ drawRestrictedZones(); scDraw=true; }catch(e){ window.__res.push('SC5:EXC '+e.message); }
    window.__res.push('SC5:'+(scDraw?'OK':'FAIL')+' (drawRestrictedZones con SECTORES sin excepción)');
    // ── Test 12: botón SECTORES + toggles individuales (CHARLIE..INDIA) ──
    var sectBtn=document.getElementById('sectBtn');
    window.__res.push('SC6:'+(sectBtn&&sectBtn.textContent.indexOf('SECTORES')>=0?'OK':'FAIL')+' (botón SECTORES en barra GEN)');
    var namesOk=SECT_NAMES.length===7&&SECT_NAMES.indexOf('DELTA')>=0&&SECT_NAMES.indexOf('FOXTROT')>=0;
    window.__res.push('SC7:'+(namesOk?'OK':'FAIL')+' (SECT_NAMES 7 sectores: '+SECT_NAMES.join(',')+')');
    window.__res.push('SC8:'+(sectoresOn.DELTA===true&&sectoresOn.CHARLIE===false?'OK':'FAIL')+' (DELTA on por defecto, CHARLIE off)');
    var before=sectoresOn.DELTA; toggleSector('DELTA');
    window.__res.push('SC9:'+(sectoresOn.DELTA===!before?'OK':'FAIL')+' (toggleSector DELTA cambia estado)');
    toggleSector('DELTA');
    var pxOn=0,pxOff=0;
    try{
      var cv2=document.getElementById('rc');
      var ctx2=cv2.getContext('2d');
      function countGold(){var d=ctx2.getImageData(0,0,cv2.width,cv2.height).data;var n=0;for(var i=0;i<d.length;i+=4){var r=d[i],g=d[i+1],b=d[i+2],a=d[i+3];if(a>0&&r>g+20&&r>=150&&g>=120&&b<=140){n++;}}return n;}
      // Dibujo síncrono (forceRedraw es asíncrono vía rAF): replicar frame()
      // sin drawAC/drawLiveAircraft (no hay aeronaves en el contexto de test)
      function drawSync(){ctx.clearRect(0,0,W,H);drawBG();drawMapBackground();drawGMAPBackground();drawGrid();drawRunways();drawNAVAIDs();drawRestrictedZones();drawHolds();drawWaypoints();drawCoastline();drawLPIBorder();drawOverlay();}
      var mrvacBefore=showMRVAC,holdsBefore=showHolds;showMRVAC=false;showHolds=false;  // aislar sectores (MRVAC/holds también son verdes)
      showSectores=true;drawSync();pxOn=countGold();
      showSectores=false;drawSync();pxOff=countGold();
      showSectores=true;drawSync();
      showMRVAC=mrvacBefore;showHolds=holdsBefore;drawSync();
    }catch(e){window.__res.push('SC10:EXC '+e.message);}
    window.__res.push('SC10:'+(pxOn>0&&pxOff<pxOn?'OK':'FAIL')+' (dibujo dorado: ON='+pxOn+'px OFF='+pxOff+'px)');
    sectAll(false);
    window.__res.push('SC11:'+(sectoresOn.DELTA===false&&sectoresOn.CHARLIE===false?'OK':'FAIL')+' (sectAll(false) apaga todos)');
    sectAll(true);
    window.__res.push('SC12:'+(sectoresOn.DELTA===true&&sectoresOn.FOXTROT===true?'OK':'FAIL')+' (sectAll(true) enciende todos)');
    sectoresOn.DELTA=true;SECT_NAMES.forEach(function(n){if(n!=='DELTA')sectoresOn[n]=false;});
    // ── Test 13: escenario tablet (tránsitos UGOLA/TEGEB + Auto DEP 17R) ──
    var tabOpt=false;
    var scSel=document.getElementById('scenario');
    if(scSel){var opts=scSel.options;for(var oi=0;oi<opts.length;oi++){if(opts[oi].value==='tablet')tabOpt=true;}}
    window.__res.push('SC13:'+(tabOpt?'OK':'FAIL')+' (opción tablet en select de escenarios)');
    var prevVal=scSel?scSel.value:'';
    if(scSel)scSel.value='tablet';
    loadScenario();
    var hasUGOLA=false,hasTEGEB=false;
    aircraft.forEach(function(a){
      if(Math.abs(a.x-WPT.UGOLA.x)<0.5&&Math.abs(a.y-WPT.UGOLA.y)<0.5)hasUGOLA=true;
      if(Math.abs(a.x-WPT.TEGEB.x)<0.5&&Math.abs(a.y-WPT.TEGEB.y)<0.5)hasTEGEB=true;
    });
    window.__res.push('SC14:'+(hasUGOLA&&hasTEGEB?'OK':'FAIL')+' (tránsitos en UGOLA y TEGEB)');
    window.__res.push('SC15:'+(autoDepTimer!==null?'OK':'FAIL')+' (auto dep 17R activo)');
    stopAutoDep();
    if(scSel)scSel.value=prevVal;
    // ── Test 16: SIDs reales SCEL (AIP Chile, cartas SID 1–14) ──
    // 1) AUTO_DEP rota las 24 SIDs de la 17R y todas existen en SIDS
    var depOk=AUTO_DEP.length===24;
    AUTO_DEP.forEach(function(t){if(!SIDS[t.sid])depOk=false;});
    // 2) Todas las rutas SIDS referencian waypoints existentes (sin undefined)
    var wptOk=true,sidCount=0;
    Object.keys(SIDS).forEach(function(k){
      sidCount++;
      SIDS[k].forEach(function(p){
        if(!p||typeof p.x!=='number'||typeof p.y!=='number')wptOk=false;
      });
    });
    // 3) El pool cubre todas las SIDs 17R (24) y existen también 17L y 35L/R
    var has17L=false,has35=false;
    Object.keys(SIDS).forEach(function(k){if(/17L$/.test(k))has17L=true;if(/35[LR]$/.test(k))has35=true;});
    // 4) Los ids de salida (base+200+seq) no colisionan con llegadas/tránsitos (LAN101, SKY220…)
    var idOk=true;
    var depIds=AUTO_DEP.map(function(t){return t.base+'200';});
    ARR_TEMPLATES.forEach(function(t){if(depIds.indexOf(t.id)!==-1)idOk=false;});
    if(depIds.indexOf('LAN101')!==-1||depIds.indexOf('SKY220')!==-1)idOk=false;
    // 5) Bases ICAO únicas en el pool → ids únicos por ciclo (sin duplicados)
    var bases=AUTO_DEP.map(function(t){return t.base;});
    var baseOk=bases.length===new Set(bases).size;
    window.__res.push('SC16:'+(depOk&&wptOk&&has17L&&has35&&idOk&&baseOk?'OK':'FAIL')
      +' (SIDs='+sidCount+' · AUTO_DEP 17R='+AUTO_DEP.length+' · 17L='+has17L+' · 35='+has35+' · ids='+idOk+' · bases='+baseOk+')');

    // ══ Test 17-23: EJE DE PISTA + NIVEL DE VIRAJE (AIP SCEL SID 1–14) ══
    var RWYOF={'17R':177,'17L':177,'35L':357,'35R':357};
    function rwyOf(sid){var m=/_(17R|17L|35L|35R)$/.exec(sid);return m?m[1]:'';}
    function angDiff(a,b){return Math.abs(((a-b+540)%360)-180);}
    // ── SC17: cada SID arranca en el THR con el rumbo de eje de SU pista ──
    var axOk=true,axDetail='';
    Object.keys(SIDS).forEach(function(k){
      var r=rwyOf(k),p0=SIDS[k][0];
      if(!r){axOk=false;axDetail=k+':sin sufijo de pista';return;}
      if(!p0||p0.axisHdg!=RWYOF[r]){axOk=false;axDetail=k+':axisHdg='+p0.axisHdg+' exp '+RWYOF[r];}
      if(p0.x!==RWY_AXIS[r].x||p0.y!==RWY_AXIS[r].y){axOk=false;axDetail=k+':no coincide con THR '+r;}
    });
    window.__res.push('SC17:'+(axOk?'OK':'FAIL')+' (THR+rumbo de eje en las '+sidCount+' SIDs)'+(axOk?'':' · '+axDetail));
    // ── SC18: NINGUNA SID vira antes del punto publicado del primer viraje ──
    // El primer punto tras el THR debe estar «en eje»: o bien lleva `axisHdg`
    // (la aeronave mantiene el rumbo de pista hasta alcanzarlo), o bien el fix
    // cae realmente sobre el eje (±3°) y el viraje ocurre sobre el punto.
    var legOk=true,legBad=[],legAxis=0;
    Object.keys(SIDS).forEach(function(k){
      var r=rwyOf(k),p0=SIDS[k][0],p=SIDS[k][1];
      if(!p){legOk=false;legBad.push(k+':sin 2º punto');return;}
      if(p.axisHdg!=null){
        legAxis++;
        if(p.axisHdg!==RWYOF[r]){legOk=false;legBad.push(k+':axisHdg='+p.axisHdg);}
        return;
      }
      var brg=(Math.atan2(p.x-p0.x,p.y-p0.y)*180/Math.PI+360)%360;
      if(angDiff(brg,RWYOF[r])>3){legOk=false;legBad.push(k+'→'+brg.toFixed(0)+'°');}
    });
    window.__res.push('SC18:'+(legOk?'OK':'FAIL')+' (ninguna SID vira antes de su punto de eje · '+legAxis+' con axisHdg)'
      +(legOk?'':' · '+legBad.slice(0,4).join(', ')));
    // ── SC19: el viraje en nivel NO avanza antes de alcanzar la altitud ──
    function mkDepAC(sid,alt){
      var t={id:'TST'+sid.length,spd:200,alt:3000,acType:'A320'};
      t.sid=sid;
      var a=mkACwithRoute(t,SIDS[sid]);
      a.alt=alt;a.tAlt=alt;a.selAlt=alt;a.cfl=Math.round(alt/100);a.assignedFL=a.cfl;
      return a;
    }
    var gateOk=true,gateBad=[];
    Object.keys(SIDS).forEach(function(k){
      var m=SIDS[k].filter(function(p){return p.altTurn;})[0];
      if(!m)return;                                     // SID sin viraje en nivel publicado
      // 1) Muy por debajo del nivel de viraje → NO avanza y mantiene rumbo de eje
      var a=mkDepAC(k,ARP_ELEV+200),i0=a.routeIdx;
      var w=a.route[i0+1];
      if(!(w&&w.altTurn))return;
      updateRouteNav(a,0);
      if(a.routeIdx!==i0||angDiff(a.tHdg,w.axisHdg)>0.5){gateOk=false;gateBad.push(k+'@bajo');}
      if(a.tAlt!==m.altTurn){gateOk=false;gateBad.push(k+'@tAlt');}
      // 2) En el nivel de viraje → avanza al fix siguiente y apunta a él
      var b=mkDepAC(k,m.altTurn);
      updateRouteNav(b,0);
      if(b.routeIdx!==i0+1){gateOk=false;gateBad.push(k+'@nivel');}
      else{
        var nx=b.route[b.routeIdx+1];
        var brg=(Math.atan2(nx.x-b.x,nx.y-b.y)*180/Math.PI+360)%360;
        if(angDiff(b.tHdg,brg)>1){gateOk=false;gateBad.push(k+'@rumbo');}
      }
    });
    window.__res.push('SC19:'+(gateOk?'OK':'FAIL')+' (ascenso en eje hasta el nivel y viraje solo al alcanzarlo)'
      +(gateOk?'':' · '+gateBad.slice(0,4).join(', ')));
    // ── SC20: viraje EN el punto (no a 1.2 NM) ──
    var p0={x:0,y:0},p1={x:0,y:20};
    var pa={role:'dep',route:[p0,p1],routeIdx:0,x:0,y:18.9,alt:5000,tAlt:5000,atcAlt:false};
    var early=routePointPassed(pa,p1,p1.x-pa.x,p1.y-pa.y,Math.hypot(p1.x-pa.x,p1.y-pa.y));
    var pb={role:'dep',route:[p0,p1],routeIdx:0,x:0,y:20.3,alt:5000,tAlt:5000,atcAlt:false};
    var onP=routePointPassed(pb,p1,p1.x-pb.x,p1.y-pb.y,Math.hypot(p1.x-pb.x,p1.y-pb.y));
    var arr={role:'arr',route:[p0,p1],routeIdx:0,x:0,y:19.0};
    var arrCap=routePointPassed(arr,p1,p1.x-arr.x,p1.y-arr.y,1.0);   // llegada conserva 1.2 NM
    window.__res.push('SC20:'+((!early&&onP&&arrCap)?'OK':'FAIL')
      +' (dep vira sobre el punto, no antes · llegada conserva captura 1.2 NM)');
    // ── SC21: mínimos y techos publicados (altMin/altMax) ──
    var consOk=true,consBad=[];
    // [sid, índice del punto en la ruta, altitud actual, tAlt esperado]
    var cs=[
      ['LINER5A_17R',1,1800,4000],     // VAGOS 4000-9000 → sube al mínimo 4000
      ['LINER5A_17R',1,12000,9000],    // sobre el techo → baja a 9000
      ['GELUS6A_17R',2,6800,7500],     // KIDUG 7500-10000 → sube a 7500
      ['GELUS6A_17R',2,12000,10000],   // sobre el techo → baja a 10000
      ['DILOK7B_17R',2,6000,7500],     // SEKSU 7500-9000 → sube a 7500
      ['DILOK7B_17R',2,9500,9000],     // sobre el techo → baja a 9000
      ['SANTIAGO5_35L',2,10000,11000], // D22AMB FL110-140 → sube a 11000
      ['SANTIAGO5_35L',2,15000,14000], // sobre el techo → baja a 14000
      ['DOMINGO1R_17R',5,5000,5500],  // LOLAT 5500-9000 → sube al mínimo 5500
      ['DILOK1R_17R',5,5500,6000],     // EL131 ≥6000 → sube a 6000
      ['DILOK1R_17R',6,6000,7000],     // EL177 ≥7000 → sube a 7000
    ];
    cs.forEach(function(c){
      var a=mkDepAC(c[0],c[2]);a.atcAlt=false;
      updateAltConstraint(a,a.route[c[1]]);
      if(a.tAlt!==c[3]){consOk=false;consBad.push(c[0]+'['+c[1]+']→'+a.tAlt+' exp '+c[3]);}
    });
    window.__res.push('SC21:'+(consOk?'OK':'FAIL')+' (altMin/altMax de las cartas respetados)'
      +(consOk?'':' · '+consBad.join(', ')));
    // ── SC22: MNM Razón ASC de cada carta aplicada al despegue ──
    var rocOk=true,rocBad=[];
    AUTO_DEP.concat(DEP_TEMPLATES).forEach(function(t){
      var base=t.sid.replace(/_(17R|17L|35L|35R)$/,''),rc=SID_ROC[base];
      if(!rc){rocOk=false;rocBad.push(t.sid+':sin ROC');return;}
      var a=mkACwithRoute(t,SIDS[t.sid]);
      if(a.sidRoc!==rc.roc||a.sidRocTil!==rc.til){rocOk=false;rocBad.push(t.sid);}
    });
    window.__res.push('SC22:'+(rocOk?'OK':'FAIL')+' (MNM Razón ASC aplicada a las 24+8 salidas)'
      +(rocOk?'':' · '+rocBad.slice(0,4).join(', ')));
    // ── SC23: escenario «Salidas SCEL» disponible en TABLET y PC ──
    // SIN ráfaga de despegues: al cargar el escenario hay exactamente 1 salida
    // (la que arranca el Auto DEP) + 2 tránsitos. El resto entra 1 cada 2 min.
    var depsOk=true,devRes=[];
    ['tablet','pc'].forEach(function(d){
      var sc=document.getElementById('scenario');
      var hadOpt=false;Array.prototype.forEach.call(sc.options,function(o){if(o.value==='deps')hadOpt=true;});
      selectDevice(d);
      var isDeps=sc.value==='deps',timer=autoDepTimer!==null;
      var dep=aircraft.filter(function(a){return a.role==='dep'&&a.axisHdg!=null;});
      var nDep=dep.length;
      var nTr=aircraft.filter(function(a){return a.role!=='dep';}).length;
      var total=aircraft.length;
      // 1 departure (from startAutoDep) + 2 transits = 3, NOT 9
      if(!hadOpt||!isDeps||!timer||nDep!==1||nTr!==2||total!==3){
        depsOk=false;devRes.push(d+'[opt='+hadOpt+' sel='+sc.value+' timer='+timer+' dep='+nDep+' tr='+nTr+' tot='+total+']');
      }
      stopAutoDep();
      devRes.push(d+'→'+sc.value+'/'+nDep+'dep');
    });
    window.__res.push('SC23:'+(depsOk?'OK':'FAIL')+' (deps en tablet y PC · sin ráfaga: '+devRes.join(' · ')+')');
    // SC27: sin ráfaga de despegues — el escenario carga 1 salida (la que arranca
    // el Auto DEP) y las siguientes solo entran por el temporizador de 2 min.
    // Verificación sincrónica: se conta lo que hay tras cargar y se comprueba
    // que loadScenario no inyecta DEP_TEMPLATES.
    var bunchOk=true,bunchInfo='';
    stopAutoDep();
    document.getElementById('scenario').value='deps';
    loadScenario();
    var n0=aircraft.filter(function(a){return a.role==='dep'&&a.axisHdg!=null;}).length;
    var nTr0=aircraft.filter(function(a){return a.role!=='dep';}).length;
    if(n0!==1)bunchOk=false;
    if(nTr0!==2)bunchOk=false;
    // Los 2 tránsitos son llegadas; ninguna salida extra debe existir.
    if(aircraft.length!==3)bunchOk=false;
    // El temporizador sigue siendo el de 2 min.
    if(AUTO_DEP_MS!==120000)bunchOk=false;
    bunchInfo='salidas al cargar='+n0+' · tránsitos='+nTr0+' · total='+aircraft.length
      +' · intervalo='+(AUTO_DEP_MS/1000)+' s · timer='+(autoDepTimer!==null);
    stopAutoDep();
    window.__res.push('SC27:'+(bunchOk?'OK':'FAIL')
      +' (1 despegue cada 2 min, sin ráfaga · '+bunchInfo+')');
    // SC28: quinta línea de la etiqueta radar = SOLO el nombre de la SID de
    // salida, en AMARILLO DORADO. Sin prefijo «SID» ni sufijo de pista.
    // Se intercepta fillText para leer texto+color de cada fila dibujada.
    var lblOk=true,lblInfo=[],lblBad=[];
    (function(){
      var log=[],orig=ctx.fillText.bind(ctx);
      ctx.fillText=function(t,x,y){log.push({t:t,st:ctx.fillStyle,y:Math.round(y)});return orig(t,x,y);};
      function mk(o){
        return Object.assign({id:'XXX999',ssr:'1234',alt:15500,cfl:160,tAlt:16000,vSpd:1500,
          gspd:250,spd:250,hdg:177,acType:'A320',wtc:'M',ias:250,selAlt:16000,
          lblX:22,lblY:-38,opcode:'',txt:''},o);
      }
      var deps=[
        mk({id:'LAN200',role:'dep',starName:'NEBEG7A_17R',depRwy:'17R',axisHdg:177}),
        mk({id:'TAM201',role:'dep',starName:'GUVOL5C_35R',depRwy:'35R',axisHdg:357}),
        mk({id:'ACA202',role:'dep',starName:'GELUS3C_35L',depRwy:'35L',axisHdg:357}),
        mk({id:'LAN203',role:'dep',starName:'DONTI6A_17L',depRwy:'17L',axisHdg:177}),
        mk({id:'LAN101',role:'arr',starName:'SIMOK1A'})          // llegada: SIN SID
      ];
      deps.forEach(function(a){log=[];drawLabel(a,300,300,false,false,false,'#34a7e9');a.log=log.slice();});
      ctx.fillText=orig;
      deps.forEach(function(a){
        // la quinta fila es el ÚLTIMO texto dibujado (no hay opcode/txt aquí)
        var rows=a.log.filter(function(r){return /^SID /.test(r.t);});
        var last=a.log[a.log.length-1];
        var idx=a.log.indexOf(last);
        if(a.role==='dep'){
          // 1) SOLO el nombre: sin «SID» delante ni «·RWY» detrás
          if(rows.length){lblBad.push(a.id+': sigue con el prefijo "SID"');}
          if(last.st!=='#ffd84d'){lblBad.push(a.id+': color '+last.st+' (no dorado)');}
          var want=a.starName.split('_')[0];
          if(last.t!==want){lblBad.push(a.id+': "'+last.t+'" ≠ "'+want+'"');}
          if(/·|_/.test(last.t)){lblBad.push(a.id+': la 5ª línea trae sufijo extra');}
          // 2) debe ser la 5ª fila: 5 textos previos (SSR cuenta como uno)
          if(idx!==5){lblBad.push(a.id+': SID en fila '+(idx+1)+' (debe ser 5)');}
          lblInfo.push(a.id+' "'+last.t+'"');
        }else{
          if(rows.length){lblBad.push(a.id+': llegada con SID');}
          if(a.log.length!==5){lblBad.push(a.id+': '+a.log.length+' filas (deben ser 5)');}
        }
      });
      lblOk=lblBad.length===0;
    })();
    window.__res.push('SC28:'+(lblOk?'OK':'FAIL')+' (5ª línea = solo nombre de SID en #ffd84d · '+lblInfo.join(' · ')+')'
      +(lblOk?'':' · '+lblBad.join(', ')));
    // SC29: la caja de la etiqueta crece con la 5ª línea (hit-test coherente)
    var hbOk=true,hbInfo='',hbBad=[];
    (function(){
      var saved=aircraft;
      var TBAR=14*DPR*labelScale*0.95;      // BAR en drawLabel() / lblAt()
      var TLH=11*DPR*labelScale*0.92;       // LH  en drawLabel() / lblAt()
      var base={
        id:'LAN200',ssr:'1234',x:0,y:0,alt:15500,cfl:160,tAlt:16000,vSpd:1500,
        gspd:250,spd:250,hdg:177,acType:'A320',wtc:'M',ias:250,selAlt:16000,
        lblX:0,lblY:0,opcode:'',txt:'',landed:false,role:'dep',
        starName:'NEBEG7A_17R',depRwy:'17R',axisHdg:177
      };
      var arr=Object.assign({},base,{id:'LAN101',role:'arr',starName:'SIMOK1A',axisHdg:null});
      // Escanea con lblAt() la superficie de la etiqueta y devuelve hasta
      // dónde llega el hit-test hacia abajo (última fila reconocida).
      function scan(a){
        aircraft=[a];
        var p=acXY(a);
        var bx=p.x+a.lblX*DPR, by=p.y+a.lblY*DPR-TBAR*0.5;
        var maxY=-1,hits=0,row5=0;
        for(var y=0;y<160;y+=1){
          for(var x=0;x<220;x+=4){
            if(lblAt(bx+x,by+y)!==0)continue;
            hits++;if(y>maxY)maxY=y;
            // ¿la 5ª fila (SID) está dentro del hit-test?
            if(y>=TBAR+TLH*3&&y<TBAR+TLH*4)row5++;
          }
        }
        return{hits:hits,maxY:maxY,row5:row5};
      }
      var sd=scan(base),sa=scan(arr);
      aircraft=saved;
      // 1) el despegue debe cubrir la fila 5 completa (SID)
      if(!(sd.maxY>=TBAR+TLH*4-1))hbBad.push('el despegue no cubre la 5ª fila (llega a y='+sd.maxY+', se necesita '+(TBAR+TLH*4).toFixed(1)+')');
      // 2) la llegada debe terminar ANTES de la 5ª fila (no tiene SID).
      //    Se tolera el relleno inferior de la caja (PAD = 2.5 px).
      if(!(sa.maxY<=TBAR+TLH*3+3))hbBad.push('la llegada invade la 5ª fila (llega a y='+sa.maxY+')');
      // 3) la caja del despegue debe ser más alta que la de la llegada
      if(!(sd.maxY>sa.maxY))hbBad.push('caja despegue h='+sd.maxY+' ≤ llegada h='+sa.maxY);
      // 4) ambas etiquetas deben ser seleccionables
      if(sd.hits<20||sa.hits<20)hbBad.push('hit-test demasiado estrecho');
      hbOk=hbBad.length===0;
      hbInfo='despegue hasta y='+sd.maxY+'px (5ª fila covered: '+(sd.maxY>=TBAR+TLH*4-1)+') · '
        +'llegada hasta y='+sa.maxY+'px (sin 5ª fila: '+(sa.maxY<=TBAR+TLH*3+3)+')';
    })();
    window.__res.push('SC29:'+(hbOk?'OK':'FAIL')+' (hit-test cubre la 5ª línea · '+hbInfo+')'
      +(hbOk?'':' · '+hbBad.join(', ')));
    // SC24: intervalo de 2 minutos exacto y pools con SIDs por pista
    var ivOk=(AUTO_DEP_MS===120000);
    var poolOk=true,poolBad=[];
    ['17R','17L','35L','35R'].forEach(function(rw){
      var p=autoDepPool(rw);
      if(!p||!p.length){poolOk=false;poolBad.push(rw+':vacío');return;}
      p.forEach(function(t){if(!SIDS[t.sid])poolOk=false;});
      if(!p.every(function(t){return t.sid.endsWith('_'+rw);}))poolOk=false;
    });
    window.__res.push('SC24:'+(ivOk&&poolOk?'OK':'FAIL')
      +' (intervalo '+(AUTO_DEP_MS/1000)+' s · pools 17R='+autoDepPool('17R').length
      +' 17L='+autoDepPool('17L').length+' 35L='+autoDepPool('35L').length+' 35R='+autoDepPool('35R').length+')'
      +(poolOk?'':' · '+poolBad.join(', ')));
    // SC25: modo ROTAR → un despegue por pista, en ciclo 17R→17L→35L→35R
    var rotOk=true,rotBad=[],rotSeen=[];
    stopAutoDep();
    var savedAc=aircraft;aircraft=[];      // no contaminar el resto de tests
    var savedMode=autoDepRwyMode, savedSeq=autoDepSeq;
    autoDepRwyMode='ROTAR';autoDepSeq=0;
    for(var q=0;q<8;q++){spawnDep();rotSeen.push(aircraft[aircraft.length-1].depRwy);}
    var exp=['17R','17L','35L','35R','17R','17L','35L','35R'];
    if(rotSeen.join()!==exp.join()){rotOk=false;rotBad.push(rotSeen.join('>'));}
    // ids únicos en el ciclo completo
    var rids=aircraft.map(function(a){return a.id;});
    if(rids.length!==new Set(rids).size){rotOk=false;rotBad.push('ids duplicados');}
    // cada salida nace en el THR de su pista, en rumbo de eje
    aircraft.forEach(function(a){
      if(Math.abs(a.hdg-RWYOF[a.depRwy])>0.5){rotOk=false;rotBad.push(a.id+' hdg '+a.hdg.toFixed(0));}
    });
    window.__res.push('SC25:'+(rotOk?'OK':'FAIL')+' (ROTAR cicla '+rotSeen.join(' → ')+')'
      +(rotOk?'':' · '+rotBad.join(', ')));
    // SC26: modo pista fija → todas las salidas de esa pista
    var fixOk=true,fixRes=[];
    ['17L','35L','35R'].forEach(function(rw){
      aircraft=[];autoDepRwyMode=rw;autoDepSeq=0;
      for(var z=0;z<6;z++)spawnDep();
      var all=aircraft.every(function(a){return a.depRwy===rw&&a.starName.endsWith('_'+rw);});
      var ids=aircraft.map(function(a){return a.id;});
      var uniq=ids.length===new Set(ids).size;
      if(!all||!uniq){fixOk=false;fixRes.push(rw+' mal');}
    });
    // y vuelta a 17R por defecto
    aircraft=[];autoDepRwyMode='17R';autoDepSeq=0;
    for(var y=0;y<3;y++)spawnDep();
    var back=aircraft.every(function(a){return a.depRwy==='17R';});
    if(!back){fixOk=false;fixRes.push('17R mal');}
    aircraft=savedAc;autoDepRwyMode=savedMode;autoDepSeq=savedSeq;
    window.__res.push('SC26:'+(fixOk?'OK':'FAIL')+' (pista fija: 17L/35L/35R sin mezclas · vuelve a 17R)'
      +(fixOk?'':' · '+fixRes.join(', ')));
    // Restaurar defaults para no afectar nada más
    LANG_IMPLICITO.hdg=['rumbo','heading','hdg','fly','vire','vira','gir','turn','curso','proa','steer'];
    LANG_IMPLICITO.climb=['sub','asciend','ascend','climb','trep','subir','go up'];
    LANG_IMPLICITO.descend=['baj','desciend','descend','descent','go down'];
    LANG_IMPLICITO.spd=['velocidad','speed','reduce','reduzc','disminu','slow','aument','increase','nudos','knots'];
    LANG_IMPLICITO.direct=['directo','diríjase','dirígete','direct','proceed direct','go direct','vaya directo','ve directo','vaya','ve a','go to'];
    LANG_IMPLICITO.hold=['espera','espere','esperando','hold','holding','patrón de espera'];
    _buildLangRegexes();
  }catch(e){
    window.__res.push('EXC:'+e.message+' @'+(e.lineNumber||''));
  }
  document.title='RES::'+window.__res.join(' | ');
})();
